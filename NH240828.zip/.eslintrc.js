module.exports = {
  extends : ['airbnb','prettier'],
  rules : {
    'vue/multi-word-component-names' :'off'
  }
};